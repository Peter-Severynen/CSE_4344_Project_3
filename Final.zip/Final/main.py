# -*- coding: utf-8 -*-
"""
Main.py is the script that will run all other files.
Authors:
Peter Severynen 1000932156
Carlos Bustos 1001317137
"""

"""
To import a file just use import file_name 
Do NOT add the .py
RENAME THE FILE IF IT HAS A SPACE
"""

import routerA
import routerB
import routerC
import routerD
import routerE
import routerF
import routerG
import routerL
#execute serverlog.py
import serverlog
import tcp_packet
