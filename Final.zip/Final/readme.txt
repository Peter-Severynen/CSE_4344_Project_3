Peter Severynen 1000932156
Carlos Bustos	1001317137
May 8, 2018
Project 3

System Requirements:
To have the program run correctly Windows 10 is the recommended operating system and the user needs to have a Python IDE that supports
Python 3.0 or greater. The user will need to execute main.py which will then execute all other files. 

Executing the program:
The program consist of multiple python files for the client/server, tcp packets, and driver file which? will execute the program all together.
The user has to make sure all files are located in the same directory. Once the files are all in the same directory, the user can open their
preferred Python IDE IN ADMINISTRATOR MODE and open the main.py. Once the use has main.py open run the program which will run the client and server as well as
Dijkstra's algorithm. The display should show all the messages being send between the agents. Once main.py has run there should be 3 new files
in the directory which are the logs of communication between two agents.


Sources:
https://stackoverflow.com/questions/35988/c-like-structures-in-python
https://pypi.python.org/pypi/Dijkstar/2.2
https://anh.cs.luc.edu/python/hands-on/3.1/handsonHtml/io.html
http://www.bogotobogo.com/python/python_Dijkstras_Shortest_Path_Algorithm.php
https://stackoverflow.com/questions/13795758/what-is-sys-maxint-in-python-3
https://stackoverflow.com/questions/7370801/measure-time-elapsed-in-python/7370824
